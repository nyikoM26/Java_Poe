package javaapplication3;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class StoredMessages {
    private String[] messageID = new String[100];
    private String[] messageHash = new String[100];
    private String[] messageText = new String[100];
    private String[] messageRecipient = new String[100];
    private String[] messageSender = new String[100];
    private int messageCount = 0;

    public StoredMessages() {
        loadFromJSON();
    }

    public void addStoredMessage(String id, String hash, String text, String sender, String recipient) {
        if (messageCount < messageID.length) {
            messageID[messageCount] = id;
            messageHash[messageCount] = hash;
            messageText[messageCount] = text;
            messageSender[messageCount] = sender;
            messageRecipient[messageCount] = recipient;
            messageCount++;
            saveToJSON();
            System.out.println("Message stored successfully.");
        } else {
            System.out.println("Storage is full. Cannot add more messages.");
        }
    }

    public int getMessageCount() {
        return messageCount;
    }

    private void saveToJSON() {
        JSONArray list = new JSONArray();
        for (int i = 0; i < messageCount; i++) {
            JSONObject obj = new JSONObject();
            obj.put("messageID", messageID[i]);
            obj.put("messageHash", messageHash[i]);
            obj.put("messageText", messageText[i]);
            obj.put("messageSender", messageSender[i]);
            obj.put("messageRecipient", messageRecipient[i]);
            list.add(obj);
        }
        try (FileWriter file = new FileWriter("storedMessages.json")) {
            file.write(list.toJSONString());
        } catch (IOException e) {
            System.out.println("Could not save stored messages: " + e.getMessage());
        }
    }

    private void loadFromJSON() {
        try (FileReader reader = new FileReader("storedMessages.json")) {
            JSONParser parser = new JSONParser();
            JSONArray list = (JSONArray) parser.parse(reader);
            for (Object o : list) {
                JSONObject obj = (JSONObject) o;
                messageID[messageCount] = (String) obj.get("messageID");
                messageHash[messageCount] = (String) obj.get("messageHash");
                messageText[messageCount] = (String) obj.get("messageText");
                messageSender[messageCount] = (String) obj.get("messageSender");
                messageRecipient[messageCount] = (String) obj.get("messageRecipient");
                messageCount++;
            }
        } catch (Exception e) {
            // No file yet on first run - normal, ignore
        }
    }

    public void showStoredMessagesMenu(Scanner input) {
        int option = 0;
        while (option != 7) {
            System.out.println("\n===== STORED MESSAGES MENU =====");
            System.out.println("1. Display all stored messages");
            System.out.println("2. Display the longest stored message");
            System.out.println("3. Search for a message by ID");
            System.out.println("4. Search for messages by recipient");
            System.out.println("5. Delete a message using its hash");
            System.out.println("6. Display the stored messages report");
            System.out.println("7. Return to QuickChat menu");
            System.out.print("Choose an option (1-7): ");
            if (input.hasNextInt()) {
                option = input.nextInt();
                input.nextLine();
                validateMenuOption(option, input);
            } else {
                System.out.println("Invalid input. Please enter a number.");
                input.nextLine();
            }
        }
        System.out.println("Returning to QuickChat menu...");
    }

    private void validateMenuOption(int option, Scanner input) {
        switch (option) {
            case 1: displayStoredSendersAndRecipients(); break;
            case 2: getLongestStoredMessage(); break;
            case 3: searchByMessageID(input); break;
            case 4: searchByRecipient(input); break;
            case 5: deleteByMessageHash(input); break;
            case 6: generateReport(); break;
            case 7: System.out.println("Returning to QuickChat menu..."); break;
            default: System.out.println("Invalid option. Please choose a number from 1 to 7."); break;
        }
    }

    private void displayStoredSendersAndRecipients() {
        if (messageCount == 0) { System.out.println("There are no stored messages."); return; }
        for (int i = 0; i < messageCount; i++) {
            System.out.println("\nMessage ID: " + messageID[i]);
            System.out.println("Sender: " + messageSender[i]);
            System.out.println("Recipient: " + messageRecipient[i]);
            System.out.println("Message: " + messageText[i]);
            System.out.println("Hash: " + messageHash[i]);
        }
    }

    private void getLongestStoredMessage() {
        if (messageCount == 0) { System.out.println("There are no stored messages."); return; }
        int longestIndex = 0;
        for (int i = 1; i < messageCount; i++) {
            if (messageText[i].length() > messageText[longestIndex].length()) longestIndex = i;
        }
        System.out.println("\nLongest stored message:");
        System.out.println("Message ID: " + messageID[longestIndex]);
        System.out.println("Message: " + messageText[longestIndex]);
        System.out.println("Length: " + messageText[longestIndex].length() + " characters");
    }

    private void searchByMessageID(Scanner input) {
        System.out.print("Enter the message ID: ");
        String searchID = input.nextLine();
        boolean found = false;
        for (int i = 0; i < messageCount; i++) {
            if (messageID[i].equalsIgnoreCase(searchID)) {
                System.out.println("Message found!");
                System.out.println("Sender: " + messageSender[i]);
                System.out.println("Recipient: " + messageRecipient[i]);
                System.out.println("Message: " + messageText[i]);
                found = true; break;
            }
        }
        if (!found) System.out.println("No message found with that ID.");
    }

    private void searchByRecipient(Scanner input) {
        System.out.print("Enter the recipient: ");
        String searchRecipient = input.nextLine();
        boolean found = false;
        for (int i = 0; i < messageCount; i++) {
            if (messageRecipient[i].equalsIgnoreCase(searchRecipient)) {
                System.out.println("\nMessage found!");
                System.out.println("Message ID: " + messageID[i]);
                System.out.println("Sender: " + messageSender[i]);
                System.out.println("Recipient: " + messageRecipient[i]);
                System.out.println("Message: " + messageText[i]);
                found = true;
            }
        }
        if (!found) System.out.println("No messages found for that recipient.");
    }

    private void deleteByMessageHash(Scanner input) {
        System.out.print("Enter the message hash to delete: ");
        String searchHash = input.nextLine();
        int foundIndex = -1;
        for (int i = 0; i < messageCount; i++) {
            if (messageHash[i].equals(searchHash)) { foundIndex = i; break; }
        }
        if (foundIndex == -1) { System.out.println("No message found with that hash."); return; }
        for (int i = foundIndex; i < messageCount - 1; i++) {
            messageID[i] = messageID[i + 1];
            messageHash[i] = messageHash[i + 1];
            messageText[i] = messageText[i + 1];
            messageSender[i] = messageSender[i + 1];
            messageRecipient[i] = messageRecipient[i + 1];
        }
        messageCount--;
        messageID[messageCount] = null;
        messageHash[messageCount] = null;
        messageText[messageCount] = null;
        messageSender[messageCount] = null;
        messageRecipient[messageCount] = null;
        saveToJSON();
        System.out.println("Message deleted successfully.");
    }

    private void generateReport() {
        System.out.println("\n===== STORED MESSAGES REPORT =====");
        System.out.println("Total stored messages: " + messageCount);
        if (messageCount == 0) { System.out.println("No stored messages to report."); return; }
        for (int i = 0; i < messageCount; i++) {
            System.out.println("\nMessage " + (i + 1));
            System.out.println("ID: " + messageID[i]);
            System.out.println("Hash: " + messageHash[i]);
            System.out.println("Sender: " + messageSender[i]);
            System.out.println("Recipient: " + messageRecipient[i]);
            System.out.println("Message: " + messageText[i]);
        }
    }
}