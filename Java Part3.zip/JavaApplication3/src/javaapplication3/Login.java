package javaapplication3;

public class Login {
    private String name;
    private String surname;
    private String storedUsername;
    private String storedPassword;

    public Login(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*[0-9].*") &&
               password.matches(".*[!@#$%^&*()_+\\-={}:;\"'<>,.?].*");
    }

    public boolean checkCellPhoneNumber(String cell) {
        return cell.matches("^\\+27[6-8][0-9]{8}$");
    }

    public String registerUser(String username, String password, String cell, String name, String surname) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted.";
        }
        if (!checkCellPhoneNumber(cell)) {
            return "Cellphone number is incorrectly formatted.";
        }
        this.storedUsername = username;
        this.storedPassword = password;
        return "User has been registered successfully.";
    }

    public String returnLoginStatus(String enteredUser, String enteredPass) {
        return "Welcome " + name + " " + surname + ", it is great to see you again.";
    }

    public boolean loginUser(String enteredUser, String enteredPass, String realUser, String realPass) {
        return enteredUser.equals(realUser) && enteredPass.equals(realPass);
    }
}