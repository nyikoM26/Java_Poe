package javaapplication3;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;

public class JavaApplication3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String name, surname, userName, passWord, cellPhone;

        System.out.println("Enter your name:");
        name = input.nextLine();
        System.out.println("Enter your surname:");
        surname = input.nextLine();

        Login user = new Login(name, surname);

        while (true) {
            System.out.println("Enter your username:");
            userName = input.nextLine();
            if (user.checkUserName(userName)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            }
        }

        while (true) {
            System.out.println("Enter your password:");
            passWord = input.nextLine();
            if (user.checkPasswordComplexity(passWord)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            }
        }

        while (true) {
            System.out.println("Enter your cellphone number:");
            cellPhone = input.nextLine();
            if (user.checkCellPhoneNumber(cellPhone)) {
                System.out.println("Cellphone number successfully added.");
                break;
            } else {
                System.out.println("Cellphone number is incorrectly formatted or does not contain international code, please correct the number and try again. Example +27716774402");
            }
        }

        System.out.println(user.registerUser(userName, passWord, cellPhone, name, surname));
        saveUserToJSON(userName, passWord, cellPhone, name, surname);

        System.out.println("\n======================================");
        System.out.println("                LOGIN");
        System.out.println("======================================");
        
        while (true) {
            System.out.print("Enter your username: ");
            String enteredUserName = input.nextLine();
            System.out.print("Enter your password: ");
            String enteredPassword = input.nextLine();

            if (user.loginUser(enteredUserName, enteredPassword, userName, passWord)) {
                System.out.println("");
                System.out.println(user.returnLoginStatus(enteredUserName, enteredPassword));
                break;
            } else {
                System.out.println("");
                System.out.println("Username or password incorrect, please try again.");
                System.out.println("Please try again.");
                System.out.println("");
            }
        }

        System.out.println("\n======================================");
        System.out.println("       Welcome to QuickChat.");
        System.out.println("======================================");
        
        sendmessage.startQuickChat(input, name);
        input.close();
    }
    
    public static void saveUserToJSON(String username, String password, String cell, String name, String surname) {
        JSONObject userObject = new JSONObject();
        userObject.put("username", username);
        userObject.put("password", password);
        userObject.put("cellphone", cell);
        userObject.put("name", name);
        userObject.put("surname", surname);
        
        try (FileWriter file = new FileWriter("users.json")) {
            file.write(userObject.toJSONString());
        } catch (IOException e) {
            System.out.println("Error saving JSON: " + e.getMessage());
        }
    }
}