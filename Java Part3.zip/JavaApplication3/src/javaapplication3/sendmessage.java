package javaapplication3;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class sendmessage {
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static int nextMessageNumber = 1;
    private static StoredMessages stored = new StoredMessages();

    public static void startQuickChat(Scanner input, String name) {
        System.out.println("\n======================================");
        System.out.println("       Welcome to QuickChat.");
        System.out.println("======================================");
        boolean running = true;
        while (running) {
            System.out.println("\n======================================");
            System.out.println("              QUICKCHAT");
            System.out.println("======================================");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Stored Messages");
            System.out.println("4. Quit");
            System.out.print("Choose an option: ");
            String option = input.nextLine();
            switch (option) {
                case "1": sendOneMessage(input, name); break;
                case "2": displayMessages(); break;
                case "3":
                    stored.showStoredMessagesMenu(input);
                    System.out.println("\nBack in QuickChat menu...");
                    break;
                case "4":
                    running = false;
                    System.out.println("Thank you for using QuickChat. Goodbye!");
                    break;
                default: System.out.println("Invalid option. Please try again."); break;
            }
        }
    }

    public static void sendOneMessage(Scanner input, String senderName) {
        System.out.println("\n======================================");
        System.out.println("MESSAGE " + nextMessageNumber);
        System.out.println("======================================");
        String messageID = createMessageID();
        System.out.println("Message ID generated: " + messageID);
        System.out.print("Enter recipient cellphone number: ");
        String recipient = input.nextLine();
        if (!checkRecipientCell(recipient)) {
            System.out.println("Cellphone number is incorrectly formatted or does not contain international code. Example +27718693002");
            return;
        }
        System.out.print("Enter your message: ");
        String messageText = input.nextLine();
        if (messageText.length() > 250) {
            System.out.println("Please enter a message of less than 250 characters.");
            return;
        }
        String messageHash = createMessageHash(messageID, nextMessageNumber, messageText);
        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message");
        System.out.print("Choose an option: ");
        String choice = input.nextLine();
        if (choice.equals("1")) {
            Message newMessage = new Message(messageID, nextMessageNumber, recipient, messageText, messageHash, "Sent");
            sentMessages.add(newMessage);
            saveMessagesToJSON();
            displayMessage(newMessage);
        } else if (choice.equals("2")) {
            System.out.println("Message disregarded.");
        } else if (choice.equals("3")) {
            stored.addStoredMessage(messageID, messageHash, messageText, senderName, recipient);
            System.out.println("Message stored. View it in Option 3 > Stored Messages.");
        } else {
            System.out.println("Invalid choice. Message disregarded.");
        }
        nextMessageNumber++;
    }

    public static String createMessageID() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9000000000L) + 1000000000L;
        return String.valueOf(id);
    }

    public static boolean checkRecipientCell(String recipient) {
        return recipient != null && recipient.matches("^\\+27[6-8][0-9]{8}$");
    }

    public static String createMessageHash(String messageID, int messageNumber, String messageText) {
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        String firstTwo = messageID.substring(0, 2);
        return (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    public static void displayMessages() {
        if (sentMessages.isEmpty()) { System.out.println("No messages yet."); return; }
        for (Message m : sentMessages) { displayMessage(m); }
    }

    public static void displayMessage(Message message) {
        System.out.println("\n------------------------------");
        System.out.println("MessageID: " + message.messageID);
        System.out.println("Message Hash: " + message.messageHash);
        System.out.println("Recipient: " + message.recipient);
        System.out.println("Message: " + message.messageText);
        System.out.println("------------------------------");
    }

    public static void saveMessagesToJSON() {
        JSONArray messageList = new JSONArray();
        for (Message m : sentMessages) {
            JSONObject obj = new JSONObject();
            obj.put("messageID", m.messageID);
            obj.put("recipient", m.recipient);
            obj.put("messageText", m.messageText);
            obj.put("messageHash", m.messageHash);
            messageList.add(obj);
        }
        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(messageList.toJSONString());
        } catch (IOException e) {
            System.out.println("Could not save: " + e.getMessage());
        }
    }

    public static class Message {
        String messageID;
        int messageNumber;
        String recipient;
        String messageText;
        String messageHash;
        String messageStatus;
        public Message(String messageID, int messageNumber, String recipient, String messageText, String messageHash, String messageStatus) {
            this.messageID = messageID;
            this.messageNumber = messageNumber;
            this.recipient = recipient;
            this.messageText = messageText;
            this.messageHash = messageHash;
            this.messageStatus = messageStatus;
        }
    }
}