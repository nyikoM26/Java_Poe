package javaapplication3;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {
    
    Login login;
    
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        login = new Login("Keabetswe", "Mokoena");
    }

    @Test
    public void testCheckUserName() {
        assertTrue(login.checkUserName("kyl_1"));
        assertFalse(login.checkUserName("kyle"));
        assertFalse(login.checkUserName("kyle123"));
    }

    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
        assertFalse(login.checkPasswordComplexity("password"));
        assertFalse(login.checkPasswordComplexity("Password1"));
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27718693002"));
        assertFalse(login.checkCellPhoneNumber("0718693002"));
    }

    @Test
    public void testRegisterUser() {
        String result = login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27718693002", "Keabetswe", "Mokoena");
        assertEquals("User has been registered successfully.", result);
    }

    @Test
    public void testReturnLoginStatus() {
        String expected = "Welcome Keabetswe Mokoena, it is great to see you again.";
        assertEquals(expected, login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginUser() {
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!", "kyl_1", "Ch&&sec@ke99!"));
        assertFalse(login.loginUser("kyl_1", "wrong123", "kyl_1", "Ch&&sec@ke99!"));
    }
}