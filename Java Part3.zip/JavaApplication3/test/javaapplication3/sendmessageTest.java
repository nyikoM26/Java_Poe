package javaapplication3;

import java.io.ByteArrayInputStream;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class sendmessageTest {
    
    public sendmessageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testStartQuickChat() {
        // Simulate user typing "4" = Quit, so it does not loop forever
        String fakeInput = "4\n";
        Scanner input = new Scanner(new ByteArrayInputStream(fakeInput.getBytes()));
        sendmessage.startQuickChat(input, "Keabetswe");
        // If it quits without crashing, it passed
        assertTrue(true);
    }

    @Test
    public void testSendOneMessage() {
        // Simulate: recipient + message + choice 2 = Disregard
        String fakeInput = "+27718693002\nHi there\n2\n";
        Scanner input = new Scanner(new ByteArrayInputStream(fakeInput.getBytes()));
        sendmessage.sendOneMessage(input, "Keabetswe");
        // If it runs without crashing, it passed
        assertTrue(true);
    }

    @Test
    public void testCreateMessageID() {
        String id = sendmessage.createMessageID();
        assertNotNull(id);
        assertEquals(10, id.length());
        assertTrue(id.matches("[0-9]+"));
    }

    @Test
    public void testCheckRecipientCell() {
        // Correct - +27 + 7 + 8 numbers
        assertTrue(sendmessage.checkRecipientCell("+27718693002"));
        assertTrue(sendmessage.checkRecipientCell("+27821234567"));
        // Incorrect - no +27
        assertFalse(sendmessage.checkRecipientCell("0718693002"));
        // Incorrect - starts with 1, not 6/7/8
        assertFalse(sendmessage.checkRecipientCell("+27118693002"));
        // Incorrect - too short
        assertFalse(sendmessage.checkRecipientCell("+2771869300"));
    }

    @Test
    public void testCreateMessageHash() {
        String hash = sendmessage.createMessageHash("0012345678", 0, "Hi there");
        assertEquals("00:0:HITHERE", hash);

        String hash2 = sendmessage.createMessageHash("1234567890", 1, "Hello world today");
        assertEquals("12:1:HELLOTODAY", hash2);
    }

    @Test
    public void testDisplayMessages() {
        sendmessage.displayMessages();
        // If it prints "No messages yet" without crashing, it passed
        assertTrue(true);
    }

    @Test
    public void testDisplayMessage() {
        sendmessage.Message msg = new sendmessage.Message(
            "0012345678",
            1,
            "+27718693002",
            "Hi there",
            "00:1:HITHERE",
            "Sent"
        );
        sendmessage.displayMessage(msg);
        assertTrue(true);
    }

    @Test
    public void testSaveMessagesToJSON() {
        sendmessage.saveMessagesToJSON();
        // If it saves without crashing, it passed
        assertTrue(true);
    }
}