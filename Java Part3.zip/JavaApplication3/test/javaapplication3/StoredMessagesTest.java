package javaapplication3;

import java.io.ByteArrayInputStream;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class StoredMessagesTest {
    
    public StoredMessagesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testAddStoredMessage() {
        StoredMessages stored = new StoredMessages();
        int before = stored.getMessageCount();

        stored.addStoredMessage(
            "1234567890",
            "12:0:HITHERE",
            "Hi there",
            "Keabetswe",
            "+27718693002"
        );

        assertEquals(before + 1, stored.getMessageCount());
    }

    @Test
    public void testGetMessageCount() {
        StoredMessages stored = new StoredMessages();
        // It loads from storedMessages.json, so it may not be 0
        // But it must never be negative
        assertTrue(stored.getMessageCount() >= 0);

        // And after adding one, it must go up by 1
        int before = stored.getMessageCount();
        stored.addStoredMessage(
            "0987654321",
            "09:1:HELLOTODAY",
            "Hello world today",
            "Keabetswe",
            "+27821234567"
        );
        assertEquals(before + 1, stored.getMessageCount());
    }

    @Test
    public void testShowStoredMessagesMenu() {
        // Simulate user typing "7" = Return to QuickChat menu, so it exits
        String fakeInput = "7\n";
        Scanner input = new Scanner(new ByteArrayInputStream(fakeInput.getBytes()));

        StoredMessages stored = new StoredMessages();
        stored.showStoredMessagesMenu(input);

        // If it returns to menu without crashing, it passed
        assertTrue(true);
    }
}