/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Javaapplication3;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginTest {

    private Login login;

    public LoginTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
        login = new Login("John", "Doe");
    }

    @AfterEach
    public void tearDown() {
    }

    // =========================
    // Test username
    // =========================
    @Test
    public void testCheckUserName() {

        // Valid username
        assertTrue(login.checkUserName("a_b"));

        // Invalid - no underscore
        assertFalse(login.checkUserName("abc"));

        // Invalid - more than 5 characters
        assertFalse(login.checkUserName("abc_de"));
    }

    // =========================
    // Test password complexity
    // =========================
    @Test
    public void testCheckPasswordComplexity() {

        // Valid password:
        // At least 8 characters, capital letter, number and special character
        assertTrue(login.checkPasswordComplexity("Password1!"));

        // Invalid - less than 8 characters
        assertFalse(login.checkPasswordComplexity("Pass1!"));

        // Invalid - no capital letter
        assertFalse(login.checkPasswordComplexity("password1!"));

        // Invalid - no number
        assertFalse(login.checkPasswordComplexity("Password!"));

        // Invalid - no special character
        assertFalse(login.checkPasswordComplexity("Password1"));
    }

    // =========================
    // Test cellphone number
    // =========================
    @Test
    public void testCheckCellPhoneNumber() {

        // Valid South African international number
        assertTrue(login.checkCellPhoneNumber("+27716774402"));

        // Invalid - does not start with +27
        assertFalse(login.checkCellPhoneNumber("0716774402"));

        // Invalid - incorrect number of digits
        assertFalse(login.checkCellPhoneNumber("+2771677440"));

        // Invalid - contains letters
        assertFalse(login.checkCellPhoneNumber("+27716774ABC"));
    }

    // =========================
    // Test register user
    // =========================
    @Test
    public void testRegisterUser() {

        // Valid registration
        String result = login.registerUser(
                "a_b",
                "Password1!",
                "+27716774402",
                "John",
                "Doe"
        );

        assertEquals("Registration successful.", result);
    }

    // =========================
    // Test login user
    // =========================
    @Test
    public void testLoginUser() {

        // Register a valid user first
        login.registerUser(
                "a_b",
                "Password1!",
                "+27716774402",
                "John",
                "Doe"
        );

        // Correct username and password
        assertTrue(login.loginUser("a_b", "Password1!"));

        // Incorrect username
        assertFalse(login.loginUser("wrong", "Password1!"));

        // Incorrect password
        assertFalse(login.loginUser("a_b", "WrongPass1!"));
    }

    // =========================
    // Test login status
    // =========================
    @Test
    public void testReturnLoginStatus() {

        // Register a valid user
        login.registerUser(
                "a_b",
                "Password1!",
                "+27716774402",
                "John",
                "Doe"
        );

        // Correct login details
        assertEquals(
                "Welcome John Doe, it is great to see you again.",
                login.returnLoginStatus("a_b", "Password1!")
        );

        // Incorrect login details
        assertEquals(
                "Username or password incorrect, please try again.",
                login.returnLoginStatus("a_b", "WrongPass1!")
        );
    }
}
