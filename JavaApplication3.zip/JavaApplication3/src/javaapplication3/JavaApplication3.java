
package Javaapplication3;

import java.util.Scanner;

public class JavaApplication3 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Variables
        String name;
        String surname;
        String userName;
        String passWord;
        String cellPhone;

        // =========================
        // Enter name
        // =========================
        System.out.println("Enter your name:");
        name = input.nextLine();

        // =========================
        // Enter surname
        // =========================
        System.out.println("Enter your surname:");
        surname = input.nextLine();

        // Create Login object
        Login user = new Login(name, surname);

        // =========================
        // Enter username
        // =========================
        while (true) {

            System.out.println("Enter your username:");
            userName = input.nextLine();

            if (user.checkUserName(userName)) {

                System.out.println("Username successfully captured.");
                break;

            } else {

                System.out.println("Username is not correctly formatted.");
                System.out.println("Please ensure that your username contains an underscore (_) and is no more than 5 characters long.");
            }
        }

        // =========================
        // Enter password
        // =========================
        while (true) {

            System.out.println("Enter your password:");
            passWord = input.nextLine();

            if (user.checkPasswordComplexity(passWord)) {

                System.out.println("Password successfully captured.");
                break;

            } else {

                System.out.println("Password is not correctly formatted.");
                System.out.println("Please ensure that the password contains at least 8 characters,");
                System.out.println("a capital letter, a number and a special character.");
            }
        }

        // =========================
        // Enter cellphone number
        // =========================
        while (true) {

            System.out.println("Enter your cellphone number:");
            cellPhone = input.nextLine();

            if (user.checkCellPhoneNumber(cellPhone)) {

                System.out.println("Cellphone number successfully added.");
                break;

            } else {

                System.out.println("Cellphone number is incorrectly formatted.");
                System.out.println("Please use the international format.");
                System.out.println("For example: +27716774402");
            }
        }

        // =========================
        // Register user
        // =========================
        String registrationMessage = user.registerUser(
                userName,
                passWord,
                cellPhone,
                name,
                surname
        );

        System.out.println(registrationMessage);

        // =========================
        // Login
        // =========================
        System.out.println("\n===== LOGIN =====");

        System.out.println("Enter your username:");
        String enteredUserName = input.nextLine();

        System.out.println("Enter your password:");
        String enteredPassword = input.nextLine();

        System.out.println(
                user.returnLoginStatus(enteredUserName, enteredPassword)
        );

        input.close();
    }
}