
package Javaapplication3;

public class Login {

    // Variables
    private String cellPhone;
    private String name;
    private String surname;

    // Variables for checking login
    private String storedUserName;
    private String storedPassWord;

    // Constructor
    public Login(String fname, String lname) {
        this.name = fname;
        this.surname = lname;
    }

    // =========================
    // Check username
    // =========================
    public boolean checkUserName(String username) {

        return username.contains("_") && username.length() <= 5;
    }

    // =========================
    // Check password complexity
    // =========================
    public boolean checkPasswordComplexity(String password) {

        boolean hasNumber = false;
        boolean hasCapital = false;
        boolean hasCharacter = false;

        // Password must have at least 8 characters
        if (password.length() < 8) {
            return false;
        }

        for (int i = 0; i < password.length(); i++) {

            char current = password.charAt(i);

            // Check for capital letter
            if (Character.isUpperCase(current)) {
                hasCapital = true;
            }

            // Check for number
            if (Character.isDigit(current)) {
                hasNumber = true;
            }

            // Check for special character
            if (!Character.isLetterOrDigit(current)) {
                hasCharacter = true;
            }
        }

        return hasCapital && hasNumber && hasCharacter;
    }

    // =========================
    // Check cellphone number
    // =========================
    public boolean checkCellPhoneNumber(String number) {

        // South African international format
        // Example: +27716774402
        String regex = "^\\+27\\d{9}$";

        return number.matches(regex);
    }

    // =========================
    // Register user
    // =========================
    public String registerUser(
            String userName,
            String passWord,
            String cellNumber,
            String name,
            String surname) {

        this.name = name;
        this.surname = surname;

        // Check username
        if (!checkUserName(userName)) {

            return "Username is not correctly formatted. "
                    + "Please ensure that your username contains an underscore "
                    + "and is no more than five characters in length.";
        }

        // Check password
        if (!checkPasswordComplexity(passWord)) {

            return "Password is not correctly formatted. "
                    + "Please ensure that the password contains at least eight "
                    + "characters, a capital letter, a number and a special character.";
        }

        // Check cellphone
        if (!checkCellPhoneNumber(cellNumber)) {

            return "Cell phone number is incorrectly formatted. "
                    + "Please use the international format.";
        }

        // Store information for login
        this.cellPhone = cellNumber;
        this.storedUserName = userName;
        this.storedPassWord = passWord;

        return "Registration successful.";
    }

    // =========================
    // Login user
    // =========================
    public boolean loginUser(String userName, String passWord) {

        return userName.equals(this.storedUserName)
                && passWord.equals(this.storedPassWord);
    }

    // =========================
    // Return login status
    // =========================
    public String returnLoginStatus(
            String userName,
            String passWord) {

        if (loginUser(userName, passWord)) {

            return "Welcome " + this.name + " " + this.surname
                    + ", it is great to see you again.";

        } else {

            return "Username or password incorrect, please try again.";
        }
    }
}