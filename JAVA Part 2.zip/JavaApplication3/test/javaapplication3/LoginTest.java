package javaapplication3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login("John", "Doe");
    }

    // =========================
    // Test username
    // =========================
    @Test
    public void testCheckUserName() {
        assertTrue(login.checkUserName("a_b"));
        assertFalse(login.checkUserName("abc")); // no underscore
        assertFalse(login.checkUserName("abc_de")); // more than 5 chars
    }

    // =========================
    // Test password complexity
    // =========================
    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(login.checkPasswordComplexity("Password1!"));
        assertFalse(login.checkPasswordComplexity("Pass1!")); // less than 8
        assertFalse(login.checkPasswordComplexity("password1!")); // no capital
        assertFalse(login.checkPasswordComplexity("Password!")); // no number
        assertFalse(login.checkPasswordComplexity("Password1")); // no special
    }

    // =========================
    // Test cellphone number
    // =========================
    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27716774402"));
        assertFalse(login.checkCellPhoneNumber("0716774402")); // no +27
        assertFalse(login.checkCellPhoneNumber("+2771677440")); // too short
    }

    // =========================
    // Test register user
    // =========================
    @Test
    public void testRegisterUser() {
        String result = login.registerUser("a_b", "Password1!", "+27716774402", "John", "Doe");
        // This must match what your Login.java returns
        assertEquals("User has been registered successfully.", result);
    }

    // =========================
    // Test login user - FIXED TO CONNECT
    // =========================
    @Test
    public void testLoginUser() {
        // We registered a_b / Password1!
        assertTrue(login.loginUser("a_b", "Password1!", "a_b", "Password1!"));
        assertFalse(login.loginUser("wrong", "Password1!", "a_b", "Password1!"));
        assertFalse(login.loginUser("a_b", "WrongPass1!", "a_b", "Password1!"));
    }

    // =========================
    // Test login status - FIXED TO CONNECT
    // =========================
    @Test
    public void testReturnLoginStatus() {
        // This matches your Login.java welcome message
        String welcome = login.returnLoginStatus("a_b", "Password1!");
        assertTrue(welcome.contains("Welcome"));
        assertTrue(welcome.contains("John"));
    }
}