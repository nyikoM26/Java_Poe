package javaapplication3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class sendmessageTest {

    @Test
    public void testCreateMessageID() {
        String id = sendmessage.createMessageID();
        assertNotNull(id);
        assertEquals(10, id.length());
        assertTrue(id.matches("\\d{10}"), "ID must be 10 numbers");
    }

    @Test
    public void testCheckRecipientCell() {
        // VALID - must start with +27 and be 12 chars total
        assertTrue(sendmessage.checkRecipientCell("+27718693002"));
        assertTrue(sendmessage.checkRecipientCell("+27838968976"));
        
        // INVALID
        assertFalse(sendmessage.checkRecipientCell("0718693002"));
        assertFalse(sendmessage.checkRecipientCell("+27718693"));
        assertFalse(sendmessage.checkRecipientCell(null));
    }

    @Test
    public void testCreateMessageHash() {
        String messageID = "0011223344";
        String hash = sendmessage.createMessageHash(messageID, 1, "Hi Mike");
        
        // Expected format from POE: firstTwo:messageNumber:FIRSTwordLASTword
        // 00:1:HIMIKE
        assertNotNull(hash);
        assertTrue(hash.startsWith("00:1:"));
        assertEquals("00:1:HIMIKE", hash);
    }

    @Test
    public void testSaveMessagesToJSON() {
        assertDoesNotThrow(() -> sendmessage.saveMessagesToJSON());
    }

    @Test
    public void testStartQuickChat() {
        // Just checks class exists and method is accessible
        assertNotNull(sendmessage.class);
    }

    @Test
    public void testSendOneMessage() {
        assertNotNull(sendmessage.class);
    }

    @Test
    public void testDisplayMessages() {
        assertDoesNotThrow(() -> sendmessage.displayMessages());
    }

    @Test
    public void testDisplayMessage() {
        String id = sendmessage.createMessageID();
        String hash = sendmessage.createMessageHash(id, 1, "Test");
        sendmessage.Message msg = new sendmessage.Message(id, 1, "+27718693002", "Test", hash, "Sent");
        
        assertDoesNotThrow(() -> sendmessage.displayMessage(msg));
    }
}